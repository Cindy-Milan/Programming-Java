/*
Cynthia Milan
Prof. Richard Biritwum
Antelope Valley College
Computer Engineering Undergrad Student
*/
import java.util.Scanner; 

public class Main {
   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);
      int arrowBaseHeight = 0;
      int arrowBaseWidth  = 0;
      int arrowHeadWidth = 0;
      
      System.out.println("Enter arrow base height:");
      arrowBaseHeight = scnr.nextInt();
      
      System.out.println("Enter arrow base width:");
      arrowBaseWidth = scnr.nextInt();
      
      System.out.println("Enter arrow head width:");
      arrowHeadWidth = scnr.nextInt();
      
   while(arrowHeadWidth <= arrowBaseWidth) {         //allows input until arrow head width is larger than base width
      System.out.println("Enter arrow head width:");
      arrowHeadWidth=scnr.nextInt();
   }
   System.out.println();
   
                                              //prints arrow base; "h" for height "w" for width, makes it easier to understand
   for (int h = 0; h < arrowBaseHeight; h++){ // prints given height
      for(int w = 0; w < arrowBaseWidth; w++){ // prints given width
       System.out.print("*");
      }
       System.out.println();                    // avoids from the code from showing all in one line
   }

                                              //prints the head arrow
   for (int j =1; j<=arrowHeadWidth; j++){     //prints the width of the rectangle
       for(int i = 1; i <=arrowHeadWidth; i++){ //prints the height of the rectangle
          if(j<=i)                                //this "if" statement declares whether a asterisk is shown or not creatin the upside down half triangle
         System.out.print("*");
       }
         System.out.println();                  // avoids the code from showing all asterisks in one line
      }
         
      
      return;
   }
}