/*

Cynthia Milan
Prof. Richard Biritwum
Antelope Valley College
Computer Engineering Undergrad Student

*/
import java.util.Scanner;

public class Main {
   public static void main(String[] args) {
    
      Scanner sc = new Scanner(System.in);               //scanner needed for array
		double[] userWeight = new double[6];               //gives the length of the array


		for(int i=1; i<6; i++){                            //loop that allows the array to start from 1 and end at 5 by giving an array from 0 to 6
		   System.out.println("Enter weight " + i+":");    //prints the line
		   userWeight[i]=sc.nextDouble();                  //helps scanner with array, double was needed not int
         
		  while(userWeight[i] < 0){
		     System.out.println("choose a valid number");
		     userWeight[i]=sc.nextDouble();
         } 


		}


	
		double sum=0;                                      // defines sum
		
		System.out.print("You entered: ");                 // prints line
		
		for(int j=1; j<userWeight.length; j++){            // loop that provides with the length from 1 to 5
		   System.out.print(userWeight[j]+" ");            // prints the weight
		   sum+=userWeight[j];                             // finds sum
		}
		
		System.out.println("\n");                          // needed by zybooks
		System.out.println("Total weight: "+sum);          // prints sum
	
	
    
		double averageOfWeight=0;                          // defines average
		
		if(userWeight.length>0){                           // if statement needed to measure values
		   averageOfWeight = sum / (userWeight.length-1);         // finds average using sum; the "-1" subtracts the added weight that should not be there
		   System.out.println("Average weight: "+averageOfWeight);     // prints average
		}
		
		
		double largest = userWeight[0];                    //needed to define max
		
		for(int uw=0; uw<userWeight.length; uw++){         //loop that measures the value lengths
		   if(userWeight[uw]>largest){                     // if statement that measures the the array values
		      largest=userWeight[uw];                      // the statement that measures the max weight
		      
		   }
		}
		System.out.print("Max weight: "+largest);          //prints the max
		System.out.println();                            // needed by zybooks
      
      return;
   }
}