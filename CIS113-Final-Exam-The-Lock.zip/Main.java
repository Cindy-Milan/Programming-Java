/*
Cynthia Milan 
Prof. Richard Biritwum
Antelope Valley College
Computer Engineering Undergrad Student
*/
import java.util.Scanner;

class Main {
  public static void Menu(){
		System.out.println("Choose an option: ");
		System.out.println("a - to add a new combination");
		System.out.println("b - to turn the knob");
		System.out.println("c - to close and reset the lock");
		System.out.println("d - attempt to open the lock");
		System.out.println("e - status of the lock (open or closed)");
		System.out.println("f - what is the current number?");
		System.out.println("q - to quit\n");
    //Menu that prints options
  }
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    int x, y, z;
    Din newLock = new Din();
    Menu();

    // x y z are the combination
    // the newLock reads the Din file and lets us use the methods
    // Menu() prints the menu we created above

    char input = scan.next().charAt(0);

    // scans for the input for the menu option

    while(input != 'q'){
    // aslong as the input is not 'q' it still keeps running
        switch(input){
          case 'a':
          System.out.println("input combination for x: ");
          x = scan.nextInt();
          System.out.println("input combination for y: ");
          y = scan.nextInt();
          System.out.println("input combination for z: ");
          z = scan.nextInt();
          newLock.combination(x,y,z);
          Menu();
          input = scan.next().charAt(0);
          break;
    // Case a: asks for the new combination 

          case 'b':
              int click = 0;
              System.out.println("Please input a combination a number of clicks: ");
              click = scan.nextInt();
              System.out.println("Please enter a direction (0) for left or (1) for right: ");
              int d = scan.nextInt();
              
                if(d == 1) {
                  newLock.ClockwiseRotation(click); 
                }
                else if(d == 0) {
                  newLock.CounterClockwise(click);
                }
                else {
                System.out.println("Please try again, Choice not an option!");
                  }
                System.out.println();
              Menu();
              input = scan.next().charAt(0);
              System.out.println();
          break;
    // the if else statement allows the pick between moving the amount of clicks clockwise or counter clockwise
    // clicks would be the amount of numbers you moved it back and forth to get the wanted combination x y or z

          case 'c':
          newLock.Reset();
          System.out.println("Locked and reset position at 0\n");
          System.out.println();
          Menu();
          input = scan.next().charAt(0);
          break;
    // this resets the position back to starting 0 and locks the lock

          case 'd':
          newLock.AttemptOpen();
          System.out.println();
          Menu();
          input = scan.next().charAt(0);
          break;
    // attempts to open the lock

          case 'e':
          newLock.Status();
          System.out.println();
          Menu();
          input = scan.next().charAt(0);
          break;
    // prints whether it is open or still locked

          case 'f':
          newLock.Position();
          System.out.println();
          Menu();
          input = scan.next().charAt(0);
          break;
    // prints the current position

          case 'q':
          break;
    // quits
          default:
          System.out.println("try again");
          System.out.println();
          Menu();
          input = scan.next().charAt(0);
          break;
    // just incase the user prints something else thats not an option

          }

          }
            }
          }