public class Din {
private int pose = 0;
private boolean locked = true;
private boolean unlockX = true;
private boolean unlockY = true;
private boolean unlockZ = true;
private int combX;
private int combY;
private int combZ;
//initialized variables used for methods or setters

//Methods
public void Lock(){
  combX = 0; combY = 0; combZ = 0;
}
//sets the combinations x y z

public void setX(int x){
  combX = x;
}
public void setY(int y){
  combY = y;
}
public void setZ(int z){
  combZ = z;
}
//these set the combinations

public void combination(int x, int y, int z){
  setX(x);
  setY(y);
  setZ(z);
}
//uses the previous setter to formally set the given input combination given by the user

public void ClockwiseRotation(int clicks) {
	if(locked) {
		pose += clicks;
		if(pose > 39) {
			pose = pose % 39;
			if(pose == combX) {
				unlockX = true;
			}
			else {
				unlockX = false;	
			}
			
		}
		if(pose < 39) {
			if(pose == combZ) {
				unlockZ = true;
			}
			else {
				unlockZ = false;
			}
		}
	}
}
//it moves the clicks turned in the clockwise or right direction

public void CounterClockwise(int clicks) {
	if(locked) {
		pose = 40 - (clicks-pose);
		if(pose < 0) {
			pose = pose *(-1);
			if(pose > 40) {
				pose = pose % 40;
			if(pose == combY) {
				unlockY = true;
			}
			else {
				unlockY = false;
			}
		}
			else {
				if(pose == combY) {
					unlockY = true;
				}
				else {
					unlockY = false;
				}
			}
		}
		if(pose > 0){
			if(pose == combY) {
				unlockY = true;
			}
			else {
				unlockY = false;
			}
		}
	}
}
//it moves the clicks toward the left or counter clockwise direction

public void AttemptOpen() {
	if(!(unlockX & unlockY & unlockZ)) {
		locked = true;
		System.out.println("Uh oh! The lock is still locked!");
  
	}
	else {
		locked = false;
		System.out.println("Congratulations! you opened the lock!");
    // the boolean is used to allow the lock to either open or not
	}
}

public void Status() {
	if(locked) {
    //boolean is still true so its locked
		System.out.println("Sorry it's locked...");
	}
	else {
		System.out.println("Its open!");
	}
}

public void Reset() {
	locked = true;
	unlockX = false;
	unlockY = false;
	unlockZ = false;
	pose = 0;
  //it turns thhe boolean to true to close the lock, and resets the unlocked combinations to lock, along with returning the position back to 0
}
public void Position() {
	System.out.println("It is currrently at " + pose);
}

}